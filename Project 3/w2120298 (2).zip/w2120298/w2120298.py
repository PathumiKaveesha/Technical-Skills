#Author:M.A.P.K. Nethsarani
#Date: 2024/12/10
#Student ID: 20231336


# Task D: Histogram Display
import tkinter as tk

class HistogramApp:
    def __init__(self, traffic_data, date):
        """
        Initializes the histogram application with the traffic data and selected date.
        """
        self.traffic_data = traffic_data
        self.date = date

        #Format the date for display
        day = self.date[0:2]
        month = self.date[2:4]
        year = self.date[4:8]
        self.date = f'{day}/{month}/{year}'
        
        self.root = tk.Tk()
        self.canvas = None  # Will hold the canvas for drawing

    def setup_window(self):
        """
        Sets up the Tkinter window and canvas for the histogram.
        """

        #Set the window title
        self.root.title(f"Histogram of Vehicle Frequency per Hour ({self.date})")

        #Create a canvas for drawing
        self.canvas = tk.Canvas(self.root, width=1200, height=500, bg='white')
        self.canvas.pack()

        self.root.update_idletasks() #Ensures any pending updates are applied

        #Bring the window to the front
        self.root.focus_force()
        self.root.attributes('-topmost',True)
        self.root.attributes('-topmost',False)

        #Add title text to the canvas
        self.canvas.create_text(
            50,10,
            text=f'Histogram of Vehicle Frequency per Hour ({self.date})',
            anchor='nw',
            font=("Arial",14,"bold")
        )

        #Add x-axis label
        self.canvas.create_text(
            600,470,
            text="hours 00:00 to 24:00",
            anchor="center",
            font=("Arial",12)
        )

        #Add the legend to the histogram
        self.add_legend()

        

    def draw_histogram(self):
        """
        Draws the histogram with axes, labels, and bars.
        """

        #Find the maximum value to scale the bars
        max_value=max(max(values) for values in self.traffic_data.values()) if self.traffic_data else 1
        scale=300/max_value #Scale factor for bar heights

        #Initialize drawing parameters
        x_start=50
        y_base=400
        bar_width=20
        spacing=10

        #Adjust the canvas width dynamically based on the number of hours
        self.canvas.config(width=(24*(2*bar_width+spacing))+100)
        line_end_x = x_start+(24*(2*bar_width+spacing))

        #Draw the x-axis
        self.canvas.create_line(x_start + spacing, y_base, line_end_x, y_base, fill='black')

        for hour in range(24):
            hour_str = f"{hour:02}"

            #Check if data exists for this hour, if not use 0 for Elm and Hanley
            elm_count, hanley_count = self.traffic_data.get(hour_str, [0,0])

            #Calculate bar heights
            elm_height = elm_count*scale
            hanley_height = hanley_count*scale

            #Draw Elm and Hanley bars
            self.canvas.create_rectangle(x_start + spacing, y_base - elm_height, x_start + bar_width + spacing, y_base, fill='light green')
            self.canvas.create_rectangle(x_start + bar_width + spacing, y_base - hanley_height,
                                         x_start + 2 * bar_width + spacing, y_base, fill='light coral')

            #Add hour label below the bars
            self.canvas.create_text(x_start + bar_width + spacing, y_base + 20, text=hour_str)

            #Displays counts on top of bars
            if elm_count>0:
                self.canvas.create_text(x_start + bar_width / 2 + spacing, y_base - elm_height - 10, text=str(elm_count), font=('Arial',10))
            if hanley_count>0:
                self.canvas.create_text(x_start + bar_width + (bar_width/2) + spacing, y_base-hanley_height-10,
                                        text=str(hanley_count), font=("Arial",10))

            #Move the starting position for the next hour
            x_start+= (2*bar_width+spacing)
             

    def add_legend(self):
        """
        Adds a legend to the histogram to indicate which bar corresponds to which junction.
        """

        #Define legend position and styles
        legend_x_start=50
        legend_y_start=40
        square_size=20
        text_offset=15
        line_spacing=25

        #Draw legend for Elm Avenue/Rabbit Road
        self.canvas.create_rectangle(
            legend_x_start, legend_y_start,
            legend_x_start + square_size, legend_y_start + square_size,
            fill='light green', outline='black'
        )

        self.canvas.create_text(
            legend_x_start + square_size + text_offset, legend_y_start + square_size//2,
            text='Elm Avenue/Rabbit Road',
            anchor='w', font=('Arial',10)
        )

        #Draw legend for Hanley Highway/Westway
        self.canvas.create_rectangle(
            legend_x_start, legend_y_start + line_spacing,
            legend_x_start + square_size, legend_y_start + line_spacing + square_size,
            fill='light coral', outline='black'
        )

        self.canvas.create_text(
            legend_x_start + square_size + text_offset, legend_y_start + line_spacing + square_size // 2,
            text="Hanley Highway/Westway",
            anchor="w", font=("Arial",10)
        )
        
           
            

    def run(self):
        """
        Runs the Tkinter main loop to display the histogram.
        """

        #Setup the window and draw the histogram
        self.setup_window()
        self.draw_histogram()

        #Start the Tkinter main loop
        self.root.mainloop()
        


# Task E: Code Loops to Handle Multiple CSV Files
class MultiCSVProcessor:
    def __init__(self):
        """
        Initializes the application for processing multiple CSV files.
        """
        self.current_data = None
        self.data = None

    def load_csv_file(self, file_path):
        """
        Loads a CSV file and processes its data.
        """

        #Store the processed data for the current file
        self.current_data={}

        file_name='results.txt'

        #Store statistics from the CSV file
        outcomes={
            'file_path': file_path,
            'total_vehicles':0,
            'total_trucks':0,
            'total_electric_vehicles':0,
            'two_wheeled_vehicles':0,
            'buses_north_rabbit_road':0,
            'straight_through_vehicles': 0,
            'vehicles_over_speed_limit':0,
            'elm_avenue_vehicles':0,
            'hanley_highway_vehicles':0,
            'elm_scooter_percentage':0,
            'peak_hour_count_hanley':0,
            'peak_hours_hanley':[],
            'hours_of_rain':0,
            'average_bikes_per_hour':0,
            'hourly_data': {f'{hour:02}': [0,0] for hour in range (24)} #[Elm, Hanley]
            
        }

        hanley_highway_vehicles={f'{hour:02}': 0 for hour in range(24)} #Hours from 00 to 23
        last_rainy_hour=None #To track the last recorded rainy hour

        try:
            with open(file_path,'r') as file:
                lines=file.readlines() #each row of the file become a list item, learned from https://diveintopython.org/functions/file-methods/readlines
                if not lines or len(lines) == 1 and not lines[0].strip():
                    print("The CSV file is empty.")
                    self.current_data=None
                    with open(file_name, 'w') as file: #using 'w' mode to clear previous outputs and write current ones
                        file.write(f"Cannot display outcomes. The file is empty.\n")
                    return

                    
                header=lines[0].strip().split(',') #Read the first line as headers

                #Process each line (skip header)
                for line in lines[1:]:
                    row=line.strip().split(',')
                    
                    #assigning the data in the list to variables
                    vehicle_type=row[header.index('VehicleType')].lower() #Column header's index is equal to the data of that column
                    junction_name=row[header.index('JunctionName')].lower()
                    vehicle_speed=int(row[header.index('VehicleSpeed')])
                    junction_speed_limit=int(row[header.index('JunctionSpeedLimit')])
                    weather_conditions=row[header.index('Weather_Conditions')].lower()
                    electric_hybrid=row[header.index('elctricHybrid')].lower()
                    travel_direction_in=row[header.index('travel_Direction_in')]
                    travel_direction_out=row[header.index('travel_Direction_out')]
                    time_of_day=row[header.index('timeOfDay')][:2]

                    #Process vehicle count
                    outcomes['total_vehicles']+=1
                    if vehicle_type=='truck':
                        outcomes['total_trucks']+=1
                    if electric_hybrid=='true':
                        outcomes['total_electric_vehicles']+=1
                    if vehicle_type in ['bicycle','motorcycle','scooter']:
                        outcomes['two_wheeled_vehicles']+=1
                        if vehicle_type=='bicycle':
                            outcomes['average_bikes_per_hour']+=1

                    #Count speed limit violations
                    if vehicle_speed>junction_speed_limit:
                        outcomes['vehicles_over_speed_limit']+=1

                    #count weather conditions (rainy hours)
                    if weather_conditions in ['light rain','heavy rain']:
                        current_hour=time_of_day [:2]
                        if current_hour!=last_rainy_hour:
                            outcomes['hours_of_rain']+=1
                            last_rainy_hour=current_hour

                    #Hanley hourly counts (Hanley Highway vehicles)
                    if junction_name=='hanley highway/westway':
                        outcomes['hourly_data'][time_of_day][1]+=1
                        hanley_highway_vehicles[time_of_day[:2]]+=1

                    #Count vehicles traveling straight through both junctions
                    if travel_direction_in==travel_direction_out:
                        outcomes['straight_through_vehicles']+=1

                    #Elm avenue vehicles and scooter percentage
                    if junction_name=='elm avenue/rabbit road':
                        outcomes['hourly_data'][time_of_day][0]+=1
                        outcomes['elm_avenue_vehicles']+=1
                        if vehicle_type=='scooter':
                            outcomes['elm_scooter_percentage']+=1

                    #Buses at Elm Avenue/Rabbit Road
                    if vehicle_type=='buss' and junction_name=='elm avenue/rabbit road' and travel_direction_out=='N':
                        outcomes['buses_north_rabbit_road']+=1


                #Calculate the total vehicles at Hanley HIghway
                outcomes['hanley_highway_vehicles']=sum(hanley_highway_vehicles.values())

                #Calculate the percentage of scooters among vehicles at Elm Avenue/Rabbit Road
                if outcomes['elm_avenue_vehicles']>0:
                    outcomes['elm_scooter_percentage']=(outcomes['elm_scooter_percentage']*100)//outcomes['elm_avenue_vehicles']


                #Peak hour calculation for Hanley
                if hanley_highway_vehicles:
                    peak_hour_count_hanley=max(hanley_highway_vehicles.values())
                    outcomes['peak_hour_count_hanley']=peak_hour_count_hanley
                    outcomes['peak_hours_hanley']=[
                        f'between {hour}:00 and {int(hour)+1}:00'
                        for hour,count in hanley_highway_vehicles.items()
                        if count==peak_hour_count_hanley
                    ]


                #Average bikes per hour
                if outcomes['average_bikes_per_hour']>0:
                    outcomes['average_bikes_per_hour']=round(outcomes['average_bikes_per_hour']/24)

                #Store outcomes in current_data
                self.current_data=outcomes

                if outcomes:
                    print("\n***************************")
                    print(f"Data file selected is {outcomes['file_path']}")
                    print("*****************************")
                    print(f"The total number of vehicles recorded for this date is {outcomes['total_vehicles']}")
                    print(f"The total number of trucks recorded for this date is {outcomes['total_trucks']}")
                    print(f"The total number of electric vehicles for this date is {outcomes['total_electric_vehicles']}")
                    print(f"The total number of two-wheeled vehicles for this date is {outcomes['two_wheeled_vehicles']}")
                    print(f"The total number of Busses leaving Elm Avenue/Rabbit Road heading North is {outcomes['buses_north_rabbit_road']}")
                    print(f"The total number of vehicles through both junctions not turning left or right is {outcomes['straight_through_vehicles']}")
                    print(f"The percentage of total vehicles recorded that are trucks for this date is {round(outcomes['total_trucks'] /outcomes['total_vehicles']*100)}%")
                    print(f"The average number of bikes per hour for this date is {outcomes['average_bikes_per_hour']}")
                    print('')
                    print(f"The total number of vehicles recorded as over the speed limit for this date is {outcomes['vehicles_over_speed_limit']}")
                    print(f"The total number of vehicles recorded through Elm Avenue/Rabbit Road junction is {outcomes['elm_avenue_vehicles']}")
                    print(f"The total number of vehicles recorded through Hanley Highway/Westway junction is {outcomes['hanley_highway_vehicles']}")
                    print(f"{outcomes['elm_scooter_percentage']}% of vehicles recorded through Elm Avenue/Rabbit Road are scooter.")
                    print('')
                    print(f"The highest number of vehicles in an hour on Hanley Highway/Westway is {outcomes['peak_hour_count_hanley']}")
                    print(f"The most vehicles through Hanley Highway/Westway were recorded {', '.join(outcomes['peak_hours_hanley'])}") #https://docs.python.org/3/library/stdtypes.html#str.join
                    print(f"The number of hours of rain for this date is {outcomes['hours_of_rain']}")
                    print("\n*******************************************")


                with open(file_name, 'w') as file: #using 'w' mode to clear previous outputs and write current ones
                    if outcomes is None: #Checking if no valid outcomes were returned
                        file.write('\n')
                        file.write(f"Cannot display outcomes. The file was not found.\n")
                        return

                    print(f'Results saved to {file_name}')
                    print('')
                    #Convert dictionary values to a list in a specific order
                    result_list=[
                        outcomes['file_path'],
                        outcomes['total_vehicles'],
                        outcomes['total_trucks'],
                        outcomes['total_electric_vehicles'],
                        outcomes['two_wheeled_vehicles'],
                        outcomes['buses_north_rabbit_road'],
                        outcomes['straight_through_vehicles'],
                        round(outcomes['total_trucks'] / outcomes['total_vehicles'] * 100) if outcomes['total_vehicles'] > 0 else 0,
                        outcomes['average_bikes_per_hour'],
                        outcomes['vehicles_over_speed_limit'],
                        outcomes['elm_avenue_vehicles'],
                        outcomes['hanley_highway_vehicles'],
                        outcomes['elm_scooter_percentage'],
                        outcomes['peak_hour_count_hanley'],
                        ', '.join(outcomes['peak_hours_hanley']),
                        outcomes['hours_of_rain']
                    ]


                    #write the current results to the file
                    file.write(f"Data file selected is {result_list[0]}\n")
                    file.write(f"The total number of vehicles recorded for this date is {result_list[1]}\n")
                    file.write(f"The total number of trucks recorded for this date is {result_list[2]}\n")
                    file.write(f"The total number of electric vehicles for this date is {result_list[3]}\n")
                    file.write(f"The total number of two-wheeled vehicles for this date is {result_list[4]}\n")
                    file.write(f"The total number of buses leaving Elm Avenue/Rabbit Road heading North is {result_list[5]}\n")
                    file.write(f"The total number of vehicles through both junctions not turning left or right is {result_list[6]}\n")
                    file.write(f"The percentage of total vehicles recorded that are trucks for this date is {result_list[7]}%\n")
                    file.write(f"The average number of bikes per hour for this date is {result_list[8]}\n")
                    file.write(f"The total number of vehicles recorded as over the speed limit for this date is {result_list[9]}\n")
                    file.write(f"The total number of vehicles recorded through Elm Avenue/Rabbit Road junction is {result_list[10]}\n")
                    file.write(f"The total number of vehicles recorded through Hanley Highway/Westway junction is {result_list[11]}\n")
                    file.write(f"{result_list[12]}% of vehicles recorded through Elm Avenue/Rabbit Road are scooters.\n")
                    file.write(f"The highest number of vehicles in an hour on Hanley Highway/Westway is {result_list[13]}\n")
                    file.write(f"The most vehicles through Hanley Highway/Westway were recorded {result_list[14]}\n")
                    file.write(f"The number of hours of rain for this date is {result_list[15]}\n")
                    file.write("\n*******************************************\n\n")



        except FileNotFoundError:
            print(f"Error: File '{file_path}' not found.")
            with open(file_name, 'w') as file: #using 'w' mode to clear previous outputs and write current ones
                file.write(f"Cannot display outcomes. The file was not found.\n")
            self.current_data=None

        except Exception as e:
            print(f'Error loading file: {e}')
            self.current_data=None


    def clear_previous_data(self):
        """
        Clears data from the previous run to process a new dataset.
        """
        self.current_data=None
        self.date=None
        

    def handle_user_interaction(self):
        """
        Handles user input for processing multiple files.
        """
        while True:
            try:
                #get the day
                day=int(input("Please enter the day of the survey in the format dd: "))
                if 1<=day<=31:
                    break #if day is valid, break the loop
                else:
                    print("Out of range - values must be in the range 1 and 31.")

            except ValueError:
                print("Integer required")


        while True:
            try:
                #get the month
                month=int(input("Please enter the month of the survey in the format MM:  "))
                if 1<=month<=12:
                    break #if month is valid, break the loop
                else:
                    print("Out of range - values must be in the range 1 to 12.")
                    
            except ValueError:
                print("Integer required")

        while True:
            try:
                #get the year
                year=int(input("Please enter the year of the survey in the format YYYY:  "))
                if 2000<=year<=2024:
                    break #if the year is valid, break the loop
                else:
                    print("Out of range - values must range from 2000 and 2024.")
                    
            except ValueError:
                print("Integer required")

        #making one digit numbers into two digit numbers

        day = f'{day:02}'
        month = f'{month:02}'
        year=str(year)


        #return the csv file name
        csv_file = f'traffic_data{day}{month}{year}.csv'
        self.date = f'{day}{month}{year}' #Store the date for later use
        return csv_file


    def process_files(self):
        """
        Main loop for handling multiple CSV files until the user decides to quit.
        """

        while True:
            csv_file = self.handle_user_interaction()

            #Load the CSV data
            self.load_csv_file(csv_file)

            if self.current_data:
                #Process and display the histogram
                app=HistogramApp(self.current_data['hourly_data'], self.date) #Pass hourly data
                app.run()

            #Ask the user if they want to load another CSV file
            while True:
                choice = input("Do you want to select a data file for a different date? (Y/N): ").strip().lower()
                if choice == 'n':
                    print("Exiting program.")
                    return
                elif choice == 'y':
                    break #Exit inner loop and continue to the next iteration of the outer loop
                else:
                    print("Invalid input. Please enter 'Y' or 'N'.")

            self.clear_previous_data()
                


#Initializing the MultiCSVProcessor() class
processor = MultiCSVProcessor()

#Calling the process_files() method to process multiple files
processor.process_files()
